use 

// Create a sample document in the 'users' collection
db.users.insertOne({
    name: "John Doe",
    email: "johndoe@example.com",
    details: "Additional user details can go here"
});
